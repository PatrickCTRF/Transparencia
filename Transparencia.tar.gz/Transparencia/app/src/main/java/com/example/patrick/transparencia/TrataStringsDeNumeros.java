package com.example.patrick.transparencia;

import android.os.Environment;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by patrick on 29/10/17.
 */

public class TrataStringsDeNumeros {

    private File fileSaida;
    private BufferedReader strings;
    private BufferedWriter stringsTratadas;
    private String stringAuxiliar;
    private ArrayList<String> listaTemporaria;
    private String numerosReais = "0123456789.";









    public void trataArquivo(File fileEntrada) {

        listaTemporaria = new ArrayList<>();

        try {
            if (!fileEntrada.exists()) {//Se o arquivo nao existe, nem prosseguimos com a função.
                Log.e("TrataStringsDeNumeros", "Erro: O arquivo não existe.");
                return;
            }

            strings = new BufferedReader(new FileReader(fileEntrada));

            stringAuxiliar = strings.readLine();//A primeira linha é apenas o nome daquela coluna no excel, então vamos pulá-la com esta instrução.

            while ((stringAuxiliar = strings.readLine()) != null) {//Lê todas as Strings de entrada e armazena numa lista após serem tratadas
                stringAuxiliar = retiraCaracteresEstranhos(stringAuxiliar);
                listaTemporaria.add(stringAuxiliar);
            }

            strings.close();

            fileSaida = new File(fileEntrada.getAbsolutePath().replace(".txt",".txt"));
            fileSaida.createNewFile();

            stringsTratadas = new BufferedWriter(new FileWriter(fileSaida));//Buffer (arquivo txt) onde escreveremos as Strings tratadas.

            for (String temporaria : listaTemporaria){//Escrvendo no arquivo tdas as Strings que tratamos neste processo.

                stringsTratadas.write(temporaria);

            }

            stringsTratadas.close();


        } catch (IOException e) {
            e.printStackTrace();
            Log.e("TrataStringsDeNumeros", " Erro ao tentar manipular os arquivos originais que seriam convertido da string original para um formato compreensível para a classe Integer.");
        }

    }







    //Recebe uma string que representa um número e retorna a mesma mas sem qualquer caractere que nao seja uma número ou ponto.
    public String retiraCaracteresEstranhos(String stringOriginal){
        String stringSaida = new String();

        for (int i = 0; i<stringOriginal.length(); i++ ){

            if(numerosReais.contains(stringOriginal.subSequence(i, i+1))){//Verificamos se o caractere na posição "i" pertence ao conjunto dos números Reais.
                stringSaida = stringSaida.concat((String) stringOriginal.subSequence(i, i+1));
            }

        }

        return stringSaida  + "\n";

    }

}








/*

 this.file = new File(Environment.getExternalStorageDirectory().toString() + "/" + "musicas" + ".txt");//Arquivo onde salvaremos os dados baxados.

 */