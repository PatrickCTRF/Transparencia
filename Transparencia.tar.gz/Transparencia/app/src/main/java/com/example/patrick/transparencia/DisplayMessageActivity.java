package com.example.patrick.transparencia;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class DisplayMessageActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private String stringTela = new String();
    private int atual = 0;
    private int total = 999;
    private int tipo = -99;
    private int selecaoSpinner = -1;
    private int elementoAtual = 1;
    private Salario salarios;
    ArrayList<Integer> resultado;
    TextView simpleTextView;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        editText = (EditText)findViewById(R.id.simpleEditText);

        simpleTextView = (TextView) findViewById(R.id.simpletextView); //get the id for TextView

        salarios = new Salario();

        Intent intent = getIntent();//Intente que iniciou esta Activity;
        tipo = intent.getIntExtra("Tipo", -1);

        if(tipo == 1){//Buscando salários

            Spinner spinner = (Spinner) findViewById(R.id.spinner3);
// Create an ArrayAdapter using the string array and a default spinner layout
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.salarios, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
            spinner.setAdapter(adapter);

            spinner.setOnItemSelectedListener(this);

        }

    }

    public void anterior(View view){
        if(elementoAtual>=1)elementoAtual--;

        stringTela = "Matrícula: " + salarios.getMatricula().get(resultado.get(elementoAtual-1) + 1) + "\n" + "Nome: " + salarios.getNome().get(resultado.get(elementoAtual-1) + 1) + "\n" + "Remuneração Bruta: " + salarios.getBruto().get(resultado.get(elementoAtual-1)) + "\n" + "Indenizações: " + salarios.getIndenizacao().get(elementoAtual) + "\n" + "Redutor: " + salarios.getRedutor().get(resultado.get(elementoAtual-1)) + "\n" + "Descontos: " + salarios.getDescontos().get(resultado.get(elementoAtual-1)) + "\n" + "Remuneração Líquida: " + salarios.getLiquido().get(resultado.get(elementoAtual-1)) + "\n" + elementoAtual + "/" + resultado.size();
        simpleTextView.setText(stringTela); //set the text after clicking button
    }

    public void proximo(View view){
        if(resultado != null && elementoAtual < resultado.size())elementoAtual++;

        stringTela = "Matrícula: " + salarios.getMatricula().get(resultado.get(elementoAtual-1) + 1) + "\n" + "Nome: " + salarios.getNome().get(resultado.get(elementoAtual-1) + 1) + "\n" + "Remuneração Bruta: " + salarios.getBruto().get(resultado.get(elementoAtual-1)) + "\n" + "Indenizações: " + salarios.getIndenizacao().get(elementoAtual) + "\n" + "Redutor: " + salarios.getRedutor().get(resultado.get(elementoAtual-1)) + "\n" + "Descontos: " + salarios.getDescontos().get(resultado.get(elementoAtual-1)) + "\n" + "Remuneração Líquida: " + salarios.getLiquido().get(resultado.get(elementoAtual-1)) + "\n" + elementoAtual + "/" + resultado.size();
        simpleTextView.setText(stringTela); //set the text after clicking button
    }

    public void buscar(View view){


        if(tipo == 1){//Buscando salários

            resultado = salarios.busca(selecaoSpinner, 1, editText.getText().toString().toUpperCase());

            if(resultado.size() > 0) stringTela = "Matrícula: " + salarios.getMatricula().get(resultado.get(elementoAtual-1) + 1) + "\n" + "Nome: " + salarios.getNome().get(resultado.get(elementoAtual-1) + 1) + "\n" + "Remuneração Bruta: " + salarios.getBruto().get(resultado.get(elementoAtual-1)) + "\n" + "Indenizações: " + salarios.getIndenizacao().get(elementoAtual) + "\n" + "Redutor: " + salarios.getRedutor().get(resultado.get(elementoAtual-1)) + "\n" + "Descontos: " + salarios.getDescontos().get(resultado.get(elementoAtual-1)) + "\n" + "Remuneração Líquida: " + salarios.getLiquido().get(resultado.get(elementoAtual-1)) + "\n" + elementoAtual + "/" + resultado.size();
            else stringTela = "Nenhum resultado encontrado.\n";

            simpleTextView.setText(stringTela); //set the text after clicking button
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {


        selecaoSpinner = position + 1;

        if(position == 3 && tipo == 1) selecaoSpinner = 6;//Pra corrigir cagada minha...

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}




/*






 */