package com.example.patrick.transparencia;

import android.os.Environment;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by patrick on 28/10/17.
 *
 * Esta classe dispõe a folha de salários de uma forma mais fácil para buscas nos difeentes parâmetros relativos a salários de funcionários.
 */

public class Salario{

    // As arraylist abaixo guardam todos os parâmetros dos funcionários numa mesma ordem. Facilita
    // a busca por diferentes parâmetros.
    private ArrayList<String> matricula;
    private ArrayList<String> nome;
    private ArrayList<String> bruto;
    private ArrayList<String> indenizacao;
    private ArrayList<String> redutor;
    private ArrayList<String> descontos;
    private ArrayList<String> liquido;


    private File fileSaida;
    private BufferedReader strings;
    private BufferedWriter stringsTratadas;
    private String stringAuxiliar;
    private ArrayList<String> listaTemporaria;
    private String numerosReais = "0123456789.";


    // Adiciona um novo elemento (Funcionário) à folha.
    public void add(String matricula, String nome, String bruto, String indenizacao, String redutor, String descontos, String liquido){

        this.matricula.add(matricula);
        this.nome.add(nome);
        this.bruto.add(bruto);
        this.indenizacao.add(indenizacao);
        this.redutor.add(redutor);
        this.descontos.add(descontos);
        this.liquido.add(liquido);

    }


    public Salario(String matricula, String nome, String bruto, String indenizacao, String redutor, String descontos, String liquido) {

        this.matricula = new ArrayList<>();
        this.nome = new ArrayList<>();
        this.bruto = new ArrayList<>();
        this.indenizacao = new ArrayList<>();
        this.redutor = new ArrayList<>();
        this.descontos = new ArrayList<>();
        this.liquido = new ArrayList<>();

        this.matricula.add(matricula);
        this.nome.add(nome);
        this.bruto.add(bruto);
        this.indenizacao.add(indenizacao);
        this.redutor.add(redutor);
        this.descontos.add(descontos);
        this.liquido.add(liquido);

    }


    public Salario(){

        this.matricula = new ArrayList<>();
        this.nome = new ArrayList<>();
        this.bruto = new ArrayList<>();
        this.indenizacao = new ArrayList<>();
        this.redutor = new ArrayList<>();
        this.descontos = new ArrayList<>();
        this.liquido = new ArrayList<>();
    }





    /**
     * Serve para encontrarmos o funcionário desejado se existir.
     *
     * Parâmetro: Varia de 0 a 6, correspondendo à busca por elementos que definimos anteriormente,
     * como: String matricula, String nome, String bruto, String indenizacao, String redutor, String descontos, String liquido.
     *
     * ParameroFiltros: Contém especificações a respeito da filtragem de busca desejada. 1 = acima, 2 = abaixo, 3 = próximo ao valor.
     *
     * Alvo: É o que estamos buscando
     *
     * Returns: Um array de string contendo os dados encontrados ou NULL se não houver correspondência.
     */
    public ArrayList<Integer> busca(int parametro, int parametroFiltros, String alvo){

        coletaDadosTXT();

        ArrayList<String> chaveiro; //Quando verificarmos qual o tipo de chave sendo buscada (nome, salario, etc...),
                                    //salvaremos aqui a mesma. Isto permite usar o mesmo trecho de código para toda a função.

        ArrayList<String> saida = new ArrayList();  //Array que guardará os resultados compatíveis.
        ArrayList<Integer> indicesSaida = new ArrayList<>();

        int contador = 0;//Conta quantos resultados foram compatíveis com aquele valor.

        double aux = 0;//Inteiro auxiliar para usar em qualquer trecho de código abaixo.

        final int margemDeErro = 1000;

        switch(parametro){

            case(0):
                chaveiro = matricula;

                contador--;//Pra descontar o título que nos demais nao tem.

                for(String chave : chaveiro){
                    if(chave.contains(alvo)){ //Se o nome sendo verificado atualmente contém o nome sendo buscado, selecione-o.
                        saida.add(chave);
                        indicesSaida.add(contador);
                        contador++;
                    }
                }

                break;

            case(1):
                chaveiro = nome;

                contador--;//Pra descontar o título que nos demais nao tem.

                for(String chave : chaveiro){
                    if(chave.contains(alvo)){ //Se o nome sendo verificado atualmente contém o nome sendo buscado, selecione-o.
                        saida.add(chave);
                        indicesSaida.add(contador);
                        }contador++;
                }

                break;

            case(2):
                chaveiro = bruto;

                for(String chave : chaveiro){

                    aux = Double.parseDouble(chave);

                    switch(parametroFiltros){
                        case(1)://Buscamos por salários de valor acima do selecionado
                            if(aux >= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(2)://Buscamos por salários com valor abaixo do selecionado.
                            if(aux <= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(3)://Buscamos por salários com valor próximo (+-1000).
                            if(aux >= -margemDeErro + Double.parseDouble(alvo) && aux <= +margemDeErro + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        default:
                            if(aux >= -1 + Double.parseDouble(alvo) && aux <= +1 + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }

                            break;
                    }
                }

                break;

            case(3):
                chaveiro = indenizacao;


                for(String chave : chaveiro){

                    aux = Double.parseDouble(chave);

                    switch(parametroFiltros){
                        case(1)://Buscamos por salários de valor acima do selecionado
                            if(aux >= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(2)://Buscamos por salários com valor abaixo do selecionado.
                            if(aux <= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(3)://Buscamos por salários com valor próximo (+-1000).
                            if(aux >= -margemDeErro + Double.parseDouble(alvo) && aux <= +margemDeErro + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        default:

                            if(aux >= -1 + Double.parseDouble(alvo) && aux <= +1 + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }

                            break;
                    }
                }

                break;

            case(4):
                chaveiro = redutor;


                for(String chave : chaveiro){

                    aux = Double.parseDouble(chave);

                    switch(parametroFiltros){
                        case(1)://Buscamos por salários de valor acima do selecionado
                            if(aux >= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(2)://Buscamos por salários com valor abaixo do selecionado.
                            if(aux <= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(3)://Buscamos por salários com valor próximo (+-1000).
                            if(aux >= -margemDeErro + Double.parseDouble(alvo) && aux <= +margemDeErro + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        default:

                            if(aux >= -1 + Double.parseDouble(alvo) && aux <= +1 + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }

                            break;
                    }
                }

                break;


            case(5):
                chaveiro = descontos;


                for(String chave : chaveiro){

                    aux = Double.parseDouble(chave);

                    switch(parametroFiltros){
                        case(1)://Buscamos por salários de valor acima do selecionado
                            if(aux >= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(2)://Buscamos por salários com valor abaixo do selecionado.
                            if(aux <= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(3)://Buscamos por salários com valor próximo (+-1000).
                            if(aux >= -margemDeErro + Double.parseDouble(alvo) && aux <= +margemDeErro + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        default:

                            if(aux >= -1 + Double.parseDouble(alvo) && aux <= +1 + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }

                            break;
                    }
                }

                break;

            case(6):
                chaveiro = liquido;


                for(String chave : chaveiro){

                    aux = Double.parseDouble(chave);

                    switch(parametroFiltros){
                        case(1)://Buscamos por salários de valor acima do selecionado
                            if(aux >= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(2)://Buscamos por salários com valor abaixo do selecionado.
                            if(aux <= Double.parseDouble(alvo)){
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        case(3)://Buscamos por salários com valor próximo (+-1000).
                            if(aux >= -margemDeErro + Double.parseDouble(alvo) && aux <= +margemDeErro + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }
                            break;

                        default:

                            if(aux >= -1 + Double.parseDouble(alvo) && aux <= +1 + Double.parseDouble(alvo)){//Janela de valores aceitos.
                                saida.add(chave);
                                indicesSaida.add(contador);
                                contador++;
                            }

                            break;
                    }
                }

                break;

            default:
                chaveiro = nome;

                for(String chave : chaveiro){
                    if(chave.contains(alvo)){ //Se o nome sendo verificado atualmente contém o nome sendo buscado, selecione-o.
                        saida.add(chave);
                        indicesSaida.add(contador);
                        contador++;
                    }
                }

                break;
        }


        return indicesSaida;
    }




    public void coletaDadosTXT(){

        for(int i = 1; i<=7;i++) {
            File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + "Salários " + i + ".txt");//Arquivo onde salvamos os dados baxados.);

            if(i >= 3){
                TrataStringsDeNumeros tratador = new TrataStringsDeNumeros();
                tratador.trataArquivo(file);
            }

            file = new File(Environment.getExternalStorageDirectory().toString() + "/" + "Salários " + i + ".txt");

            listaTemporaria = new ArrayList<>();

            try {
                if (!file.exists()) {//Se o arquivo nao existe, nem prosseguimos com a função.
                    Log.e("Salario", "Erro: O arquivo não existe.");
                    return;
                }

                strings = new BufferedReader(new FileReader(file));

                while ((stringAuxiliar = strings.readLine()) != null) {//Lê todas as Strings de entrada e armazena numa lista após serem tratadas
                    listaTemporaria.add(stringAuxiliar);
                }

                strings.close();

                switch (i){

                    case(1):
                        matricula = listaTemporaria;
                        break;

                    case(2):
                        nome = listaTemporaria;
                        break;

                    case(3):
                        bruto = listaTemporaria;
                        break;

                    case(4):
                        indenizacao = listaTemporaria;
                        break;

                    case(5):
                        redutor = listaTemporaria;
                        break;

                    case(6):
                        descontos = listaTemporaria;
                        break;

                    case(7):
                        liquido = listaTemporaria;
                        break;

                    default:

                        break;
                }

            } catch (IOException e) {
                e.printStackTrace();
                Log.e("Salario", " Erro ao tentar coletar os dados dos TXT tratados!.");
            }

        } Log.e("Salario", " Deu certo!.");

    }



    //Caso não haja filtros selecionados para a busca desejada...
    public ArrayList<Integer> busca(int parametro, String alvo){
        return busca(parametro, 0, alvo);
    }




    public ArrayList<String> getMatricula() {
        return matricula;
    }

    public ArrayList<String> getNome() {
        return nome;
    }

    public ArrayList<String> getBruto() {
        return bruto;
    }

    public ArrayList<String> getIndenizacao() {
        return indenizacao;
    }

    public ArrayList<String> getRedutor() {
        return redutor;
    }

    public ArrayList<String> getDescontos() {
        return descontos;
    }

    public ArrayList<String> getLiquido() {
        return liquido;
    }


}



































/* Rascunhos!

switch(parametro){
            case(0):

                break;

            case(1):

                break;

            case(2):

                break;

            case(3):

                break;

            case(4):

                break;

            case(5):

                break;

            case(6):

                break;
        }


 */