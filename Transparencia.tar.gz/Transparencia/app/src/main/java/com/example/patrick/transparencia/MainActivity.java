package com.example.patrick.transparencia;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.File;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spinner;
    private static final String[]paths = {"item 1", "item 2", "item 3"};
    private int tipoDeBusca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tipoDeBusca = -48;

        Spinner spinner = (Spinner) findViewById(R.id.spinnerdados);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.planets_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(this);
    }


    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {


        this.tipoDeBusca = position;

        switch (position) {
            case 0://Nada
                // Whatever you want to happen when the first item gets selected
                break;
            case 1://Salário
                // Whatever you want to happen when the second item gets selected
                sendMessage(null);
                break;
            case 2://Orçamento
                // Whatever you want to happen when the thrid item gets selected
                sendMessage(null);
                break;
            case 3://Gênero
                // Whatever you want to happen when the thrid item gets selected
                sendMessage(null);
                break;

        }
    }

    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String message = editText.getText().toString();
        intent.putExtra("Tipo", this.tipoDeBusca);
        startActivity(intent);
    }

    public void atualizaDados(View view){

        for(int i = 3; i<=7;i++){
            File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + "Salários " + i + ".txt");//Arquivo onde salvaremos os dados baxados.);
            TrataStringsDeNumeros tratador = new TrataStringsDeNumeros();
            tratador.trataArquivo(file);
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
